Note:

1. Modified the Error Query.vi to report instrument error to STDOUT but disables the Boolean error flag.
2. Clears (*.CLS) the instrument error queue, if supported.


Background: 

Unsupported functions that are called from the vendor driver sub-vis will cause "Header Invalid" errors and propagate through LabVIEW VIs and, if not handled by receiving VIs, will cause a domino-effect failure cascades.

-Aldrin

